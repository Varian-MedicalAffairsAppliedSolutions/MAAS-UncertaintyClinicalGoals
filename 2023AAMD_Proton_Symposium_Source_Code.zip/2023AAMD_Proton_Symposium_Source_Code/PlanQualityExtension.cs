// System imports
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

// For logging
using Serilog;

// For writing a JSON data file
using Newtonsoft.Json;

// ESAPI libraries
using TP = VMS.TPS.Common.Model.API;
using TPTypes = VMS.TPS.Common.Model.Types;

[assembly: TP.ESAPIScript(IsWriteable = false)]

namespace VMS.TPS
{
  public class Script
  {
    private static string pathRoot = @"C:/temp/PlanQualityExtension/"; // The result files are written here
    public static string defaultRoomId = "1"; // Record delivery times for this room (Eclipse 18.0)

    public Script()
    {
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    public void Execute(TP.ScriptContext context)
    {
      #region Validate inputs

      var plan = context.PlanSetup;
      if (plan == null)
      {
        MessageBox.Show("No plan selected. Exiting.");
        return;
      }

      if (!plan.IsDoseValid)
      {
        MessageBox.Show("Plan has no valid dose. Exiting.");
        return;
      }

      var cGoals = plan.GetClinicalGoals();
      if (cGoals == null || cGoals.Count() == 0)
      {
        MessageBox.Show("Plan contains no Clinical Goals. Exiting.");
        return;
      }

      #endregion

      #region Start logging
      // See Serilog documentation for details.

#if DEBUG
      Log.Logger = new LoggerConfiguration()
        .MinimumLevel.Debug()
        .WriteTo.File(pathRoot + "log.txt", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 1)
        .CreateLogger();
#else
      Log.Logger = new LoggerConfiguration()
        .MinimumLevel.Information()
        .WriteTo.File(pathRoot + "log.txt", rollingInterval: RollingInterval.Day, retainedFileCountLimit: 1)
        .CreateLogger();
#endif

      Log.Information($"Logging started");

      #endregion

      #region Core part

      try
      {
        WriteFieldInfoToFile(plan);

        UncertaintyGoalListContainer uncertaintyGoalListContainer = EvaluateUncertaintyGoals(plan);
        WriteUncertaintyGoalsToFile(uncertaintyGoalListContainer, plan);

        /* TODO: Uncomment if Patient name and DOB are needed.
             Mind the PHI! */
        //WritePatientInfoToFile(plan.Course.Patient);

        /* TODO: Uncomment if NTCPs are needed.
             Note that the method assumes a lung case with certain structures present with specific IDs. */
        //NtcpContainer ntcpContainer = EvaluateNtcps(plan);
        //WriteNtcpsToFile(ntcpContainer, plan);
      }
      catch (Exception e)
      {
        Log.Error(e.Message);
        throw;
      }
      finally
      {
        Log.Information($"\n\nFINISHED\n\n\n");
        Log.CloseAndFlush();
      }

      #endregion
    }

    #region NTCP Methods

    /// <summary>
    /// Evaluate the following NTCPs for the given plan:
    ///   2-Year Mortality
    ///   Esophagial toxicity G2
    ///   
    /// Both NTCPs are based on the Dutch national models.
    /// </summary>
    /// <param name="plan"></param>
    /// <returns></returns>
    private static NtcpContainer EvaluateNtcps(TP.PlanSetup plan)
    {
      Log.Information($"Evaluating NTCPs");

      var ntcpContainer = new NtcpContainer(plan);

      #region 2-Year Mortality
      // Based on the dutch lung model
      // https://nvro.nl/images/Addendum_Slokdarmcarcinoom_bij_LIPP_longcarcinoom_goedgekeurd_ZiN_151021.pdf

      var structures = plan.StructureSet.Structures;

      // Search for the predetermined GTV and Heart structures.
      // If any of these is not found, the NTCP Endpoint is skipped.
      var gtv_struct1 = structures.FirstOrDefault(x => x.Id == "GTV1_CT0");
      var gtv_struct2 = structures.FirstOrDefault(x => x.Id == "GTV2_CT0");
      var heart_struct = structures.FirstOrDefault(x => x.Id == "Heart");

      if (gtv_struct1 == null || gtv_struct2 == null || heart_struct == null)
      {
        Log.Warning($"Could not find GTV or Heart structure(s)!");
      }
      else
      {
        var vol_gtv = gtv_struct1.Volume + gtv_struct2.Volume;

        var heart_Dmean = plan.GetDVHCumulativeData(heart_struct,
          TPTypes.DoseValuePresentation.Absolute,
          TPTypes.VolumePresentation.Relative,
          0.01).MeanDose.Dose;

        var S = -1.3409
          + 0.059 * Math.Sqrt(vol_gtv)
          + 0.2635 * Math.Sqrt(heart_Dmean);
        var ntcpValue = CalculateNtcpFromS(S);

        ntcpContainer.ntcpEndpoints.Add(new NtcpEndpoint("two-year-mortality", "2-Year mortality", ntcpValue));
      }

      #endregion

      #region Esophagial toxicity G2
      // Based on the dutch lung model
      // https://nvro.nl/images/documenten/rapporten/LIPP_longen_final_01122019.pdf

      // Search for the predetermined Esophagus structure.
      // If this is not found, the NTCP Endpoint is skipped.
      var esophagus_struct = structures.FirstOrDefault(x => x.Id == "Esophagus");

      if (esophagus_struct == null)
      {
        Log.Warning($"Could not find structure Esophagus!");
      }
      else
      {
        var esophagus_Dmean = plan.GetDVHCumulativeData(heart_struct,
        TPTypes.DoseValuePresentation.Absolute,
        TPTypes.VolumePresentation.Relative,
        0.01).MeanDose.Dose;

        // Total duration in days assuming 5 fractions per week for a set of full weeks
        double treatmentDurationInDays = (double)plan.NumberOfFractions;
        if (plan.NumberOfFractions > 5)
          treatmentDurationInDays = treatmentDurationInDays * (7 / 5) - 2;

        var S = -3.634
          + 1.496 * Math.Sqrt(esophagus_Dmean)
          - 0.0297 * treatmentDurationInDays;
        var ntcpValue = CalculateNtcpFromS(S);

        ntcpContainer.ntcpEndpoints.Add(new NtcpEndpoint("esophagus-toxicity", "G2 Esophagial toxicity", ntcpValue));
      }

      #endregion

      return ntcpContainer;
    }
    private static double CalculateNtcpFromS(double S)
    {
      return 1 / (1 + Math.Exp(-1 * S));
    }

    private static void WriteNtcpsToFile(NtcpContainer ntcpContainer, TP.PlanSetup plan)
    {
      Log.Information($"Writing NTCPs to file.");

      #region Write JSON

      var filePath_json = System.IO.Path.Combine(pathRoot, plan.Course.Patient.Id, plan.Course.Id, plan.Id, "ntcps.json");
      Log.Debug($"File: {filePath_json}");

      CreateDirectoryIfNeeded(filePath_json);

      var jsonString = JsonConvert.SerializeObject(ntcpContainer);
      File.WriteAllText(filePath_json, jsonString);

      #endregion

      #region Write CSV

      var filePath_csv = System.IO.Path.Combine(pathRoot, plan.Course.Patient.Id, plan.Course.Id, plan.Id, "ntcps.csv");
      Log.Information($"File: {filePath_csv}");

      using (var stream = new StreamWriter(filePath_csv, append: false))
      {
        string headerStr = "Endpoint, Value (%)";
        stream.WriteLine(headerStr);

        foreach (var ntcpEndpoint in ntcpContainer.ntcpEndpoints)
        {
          var resultsStr = $"{ntcpEndpoint.name}, {ntcpEndpoint.value * 100.0:F1}";
          stream.WriteLine(resultsStr);
        }
      }

      #endregion
    }

    #endregion

    #region Uncertainty Goals Methods

    /// <summary>
    /// Evaluates the Clinical Goals for each Uncertainty Scenario of the plan.
    /// </summary>
    /// <param name="plan">Plan with Clinical Goals and Uncertainty Scenarios defined.</param>
    /// <returns>Container for the evaluation results. See <see cref="UncertaintyGoalListContainer"/>.</returns>
    private static UncertaintyGoalListContainer EvaluateUncertaintyGoals(TP.PlanSetup plan)
    {
      Log.Information($"Evaluating uncertainty goals.");
      var uncertaintyGoalListContainer = new UncertaintyGoalListContainer(plan);

      // Iterate the Clinical Goals.
      foreach (var cGoal in plan.GetClinicalGoals())
      {
        Log.Debug($"{cGoal.StructureId}  |>  {cGoal.ObjectiveAsString}");

        // Start a new Uncertainty Goal List for this Clinical Goal.
        var uncertaintyGoalList = new UncertaintyGoalList(cGoal.StructureId, cGoal.ObjectiveAsString, cGoal.Priority);

        // Add results for the nominal case.
        uncertaintyGoalList.uncertaintyGoals.Add(new UncertaintyGoal("Nominal", cGoal.ActualValue, cGoal.EvaluationResult));

        var tgtStructure = plan.StructureSet.Structures.FirstOrDefault(x => x.Id == cGoal.StructureId);
        if (tgtStructure == null)
          throw new ApplicationException($"Structureset '{plan.StructureSet.Id}' does not contain Clinica Goal structure '{cGoal.StructureId}'");

        // Iterate the Uncertainty Scenarios of the plan.
        foreach (var uncertainty in plan.PlanUncertainties)
        {
          if (uncertainty.Dose == null)
            continue;

          Log.Debug($"{uncertainty.DisplayName}");

          var tmpCGoal = EvaluateCGoalForUncertaintyDoses(cGoal, tgtStructure, uncertainty);
          uncertaintyGoalList.uncertaintyGoals.Add(new UncertaintyGoal(uncertainty.Id, tmpCGoal.ActualValue, tmpCGoal.EvaluationResult));
        }

        uncertaintyGoalListContainer.uncertaintyGoalLists.Add(uncertaintyGoalList);
      }

      return uncertaintyGoalListContainer;
    }

    /// <summary>
    /// Evaluates a Clinical Goal for an Uncertainty Scenario.
    /// </summary>
    /// <param name="cGoal">Clinica Goal to evaluate.</param>
    /// <param name="structure">Structure matching the cGoal target structure.</param>
    /// <param name="planUncertainty">Uncertainty Scenario where the cGoal is evaluated.</param>
    /// <returns>Copy of the cGoal object, where the evaluation data is according to the Uncertainty Scenario.</returns>
    private static TPTypes.ClinicalGoal EvaluateCGoalForUncertaintyDoses(TPTypes.ClinicalGoal cGoal, TP.Structure structure, TP.PlanUncertainty planUncertainty)
    {
      bool needsInterpolation = true; // Does the value need to be interpolated from the DVH.
      bool isDoseVal = false; // Are we reading the dose or volume value from the DVH.

      #region Resolve relative / absolute units

      var dosePresentation =
        cGoal.Objective.LimitUnit == TPTypes.ObjectiveUnit.Relative
          ? TPTypes.DoseValuePresentation.Relative
          : TPTypes.DoseValuePresentation.Absolute;

      var volumePresentation =
        cGoal.Objective.LimitUnit == TPTypes.ObjectiveUnit.Relative
          ? TPTypes.VolumePresentation.Relative
          : TPTypes.VolumePresentation.AbsoluteCm3;

      if (cGoal.MeasureType == TPTypes.MeasureType.MeasureTypeDQP_DXXX)
      {
        volumePresentation = TPTypes.VolumePresentation.Relative;
      }
      else if (cGoal.MeasureType == TPTypes.MeasureType.MeasureTypeDQP_DXXXcc)
      {
        volumePresentation = TPTypes.VolumePresentation.AbsoluteCm3;
      }
      else if (cGoal.MeasureType == TPTypes.MeasureType.MeasureTypeDQP_VXXX)
      {
        dosePresentation = TPTypes.DoseValuePresentation.Relative;
        isDoseVal = true;
      }
      else if (cGoal.MeasureType == TPTypes.MeasureType.MeasureTypeDQP_VXXXGy)
      {
        dosePresentation = TPTypes.DoseValuePresentation.Absolute;
        isDoseVal = true;
      }
      else
      {
        needsInterpolation = false;
      }

      #endregion

      #region Resolve the actual value of the goal for this Uncertainty Scenario

      double actual = Double.NaN;
      TP.DVHData dvh = planUncertainty.GetDVHCumulativeData(
        structure, dosePresentation, volumePresentation, 0.01);

      if (needsInterpolation)
      {
        actual = InterpolateDVH(dvh.CurveData, cGoal.Objective,
          isDoseVal, volumePresentation == TPTypes.VolumePresentation.AbsoluteCm3);
      }
      else
      {
        switch (cGoal.MeasureType)
        {
          case TPTypes.MeasureType.MeasureTypeDoseMax:
            actual = dvh.MaxDose.Dose;
            break;
          case TPTypes.MeasureType.MeasureTypeDoseMin:
            actual = dvh.MinDose.Dose;
            break;
          case TPTypes.MeasureType.MeasureTypeDoseMean:
            actual = dvh.MeanDose.Dose;
            break;
        }
      }

      #endregion

      // Compare the actual value against the Clinical Goal limits.
      TPTypes.GoalEvalResult evalRes = EvaluateOneGoal(cGoal, actual);

      // Build and return a new Clinical Goal object
      return new TPTypes.ClinicalGoal(
        cGoal.MeasureType, cGoal.StructureId, cGoal.Objective,
        cGoal.ObjectiveAsString, cGoal.Priority,
        cGoal.VariationAcceptable, cGoal.VariationAcceptableAsString,
        actual, String.Format("{0:F2}", actual), evalRes
      );
    }

    /// <summary>
    /// Evaluate a value against one Clinical Goal.
    /// </summary>
    /// <param name="cGoal">Clinical Goal to evaluate teh value against.</param>
    /// <param name="actual">The value to evaluate.</param>
    /// <returns>Evaluation result of the cGoal with the actual value. See <see cref="TPTypes.GoalEvalResult"/>.</returns>
    private static TPTypes.GoalEvalResult EvaluateOneGoal(TPTypes.ClinicalGoal cGoal, double actual)
    {
      double limit = cGoal.Objective.Limit;
      // If limit is Volume in cc, it has to be divided by 1000.
      if ((cGoal.MeasureType == TPTypes.MeasureType.MeasureTypeDQP_VXXXGy
           || cGoal.MeasureType == TPTypes.MeasureType.MeasureTypeDQP_VXXX)
          && cGoal.Objective.LimitUnit == TPTypes.ObjectiveUnit.Absolute)
      {
        limit /= 1000;
      }

      // Is variation acceptable
      var variation = double.IsNaN(cGoal.VariationAcceptable)
        ? 0.0
        : cGoal.VariationAcceptable;

      // Compare the limit and actual values according to the operator and acceptable variation of the Clinical Goal.
      switch (cGoal.Objective.Operator)
      {
        case TPTypes.ObjectiveOperator.GreaterThan:
          if (actual > limit)
            return TPTypes.GoalEvalResult.Passed;
          else if (!double.IsNaN(cGoal.VariationAcceptable) && actual > cGoal.VariationAcceptable)
            return TPTypes.GoalEvalResult.WithinVariationAcceptable;
          return TPTypes.GoalEvalResult.Failed;

        case TPTypes.ObjectiveOperator.GreaterThanOrEqual:
          if (actual >= limit)
            return TPTypes.GoalEvalResult.Passed;
          else if (!double.IsNaN(cGoal.VariationAcceptable) && actual >= cGoal.VariationAcceptable)
            return TPTypes.GoalEvalResult.WithinVariationAcceptable;
          return TPTypes.GoalEvalResult.Failed;

        case TPTypes.ObjectiveOperator.LessThan:
          if (actual < limit)
            return TPTypes.GoalEvalResult.Passed;
          else if (!double.IsNaN(cGoal.VariationAcceptable) && actual < cGoal.VariationAcceptable)
            return TPTypes.GoalEvalResult.WithinVariationAcceptable;
          return TPTypes.GoalEvalResult.Failed;

        case TPTypes.ObjectiveOperator.LessThanOrEqual:
          if (actual <= limit)
            return TPTypes.GoalEvalResult.Passed;
          else if (!double.IsNaN(cGoal.VariationAcceptable) && actual <= cGoal.VariationAcceptable)
            return TPTypes.GoalEvalResult.WithinVariationAcceptable;
          return TPTypes.GoalEvalResult.Failed;

        // Equal operator is not supported!
        //case ObjectiveOperator.Equals:
        //  if (Math.Abs(actual - limit) < 0.001)
        //    return GoalEvalResult.Passed;
        //  else if (!double.IsNaN(cg.VariationAcceptable) && Math.Abs(actual - limit) < (variation))
        //    return GoalEvalResult.WithinVariationAcceptable;
        //  return GoalEvalResult.Failed;

        // If none of the Objective Operator above match, return "Not Available" result.
        default:
          return TPTypes.GoalEvalResult.NA;
      }
    }

    /// <summary>
    /// Write the data from Uncertainty Goal List Container to JSON and CSV files.
    /// </summary>
    /// <param name="uncertaintyGoalListContainer"></param>
    /// <param name="plan"></param>
    private static void WriteUncertaintyGoalsToFile(UncertaintyGoalListContainer uncertaintyGoalListContainer, TP.PlanSetup plan)
    {
      Log.Information($"Writing uncertainty goals to file.");

      #region Write JSON file

      var filePath_json = System.IO.Path.Combine(pathRoot, plan.Course.Patient.Id, plan.Course.Id, plan.Id, "planUncertaintyGoals.json");
      Log.Information($"File: {filePath_json}");

      CreateDirectoryIfNeeded(filePath_json);

      var jsonString = JsonConvert.SerializeObject(uncertaintyGoalListContainer);
      File.WriteAllText(filePath_json, jsonString);

      #endregion

      #region Write CSV file

      var filePath_csv = System.IO.Path.Combine(pathRoot, plan.Course.Patient.Id, plan.Course.Id, plan.Id, "planUncertaintyGoals.csv");
      Log.Information($"File: {filePath_csv}");

      using(var stream = new StreamWriter(filePath_csv, append: false))
      {
        string headerStr = "";
        foreach (var uncertaintyGoalList in uncertaintyGoalListContainer.uncertaintyGoalLists)
        {
          // Write header row based on the first goal
          if (String.IsNullOrEmpty(headerStr))
          {
            headerStr = "Priority, Structure, Objective";
            foreach (var uncertaintyGoal in uncertaintyGoalList.uncertaintyGoals)
            {
              headerStr += ", " + uncertaintyGoal.name;
            }

            stream.WriteLine(headerStr);
          }

          // Write the results for this goal
          var resultsStr = $"{uncertaintyGoalList.priority}, " +
            $"{uncertaintyGoalList.structureId}, {uncertaintyGoalList.objective}";
          foreach (var uncertaintyGoal in uncertaintyGoalList.uncertaintyGoals)
          {
            resultsStr += $", {uncertaintyGoal.value:F2} ({uncertaintyGoal.goalResult})";
          }

          stream.WriteLine(resultsStr);
        }
      }

      #endregion


    }

    #endregion

    #region Patient and Field Info Methods

    private static void WritePatientInfoToFile(TP.Patient patient)
    {
      Log.Information($"Writing patient info to file.");

      var filePath = System.IO.Path.Combine(pathRoot, patient.Id, "patientInfo.json");
      Log.Debug($"File: {filePath}");

      CreateDirectoryIfNeeded(filePath);

      var jsonString = JsonConvert.SerializeObject(new PatientInfo(patient), Formatting.Indented);
      File.WriteAllText(filePath, jsonString);
    }

    private static void WriteFieldInfoToFile(TP.PlanSetup plan)
    {
      Log.Information($"Writing field info to file.");

      #region Write JSON

      var filePath_json = System.IO.Path.Combine(pathRoot, plan.Course.Patient.Id, plan.Course.Id, plan.Id, "fieldInfo.json");
      Log.Debug($"File: {filePath_json}");

      CreateDirectoryIfNeeded(filePath_json);

      var fieldInfo = new FieldInfo(plan);
      var jsonString = JsonConvert.SerializeObject(fieldInfo);
      File.WriteAllText(filePath_json, jsonString);

      #endregion

      #region Write CSV

      var filePath_csv = System.IO.Path.Combine(pathRoot, plan.Course.Patient.Id, plan.Course.Id, plan.Id, "fieldInfo.csv");
      Log.Information($"File: {filePath_csv}");

      using (var stream = new StreamWriter(filePath_csv, append: false))
      {
        string headerStr = "ID, Angle (deg), Monitor Units, Delivery Time (s)";
        stream.WriteLine(headerStr);

        foreach (var fieldObject in fieldInfo.fieldObjects)
        {
          var resultsStr = $"{fieldObject.id}, {fieldObject.angle:F2}, {fieldObject.monitorUnits:F2}, {fieldObject.deliveryTime:F1}";
          stream.WriteLine(resultsStr);
        }
      }

      #endregion
    }

    #endregion

    #region Generic Methods

    private static void CreateDirectoryIfNeeded(string filePath)
    {
      var fInfo = new FileInfo(filePath);
      if (!fInfo.Directory.Exists)
      {
        Log.Debug($"Creating new directory {fInfo.DirectoryName}");
        System.IO.Directory.CreateDirectory(fInfo.DirectoryName);
      }
    }

    // Interpolation without extrapolation.
    // isDoseVal -> x data should be dose and output volume.
    // isVolumeAbsolute -> Volume in cc, so the objective has to be divided by 1000 (is in mm^3 by default)
    private static double InterpolateDVH(TPTypes.DVHPoint[] data, TPTypes.Objective obj, bool isDoseVal = false, bool isVolumeAbsolute = false)
    {
      var objectiveVal = obj.Value;

      var x = data.Select(d => d.Volume);
      var y = data.Select(d => d.DoseValue.Dose);
      if (isDoseVal)
      {
        var x_tmp = x;
        x = y.Reverse();
        y = x_tmp.Reverse();
      }
      else if (isVolumeAbsolute)
      {
        objectiveVal /= 1000.0;
      }

      if (x.ElementAt(0) < objectiveVal)
      {
        return Double.NaN;
      }

      for (int i = 1; i < data.Length; i++)
      {
        if (x.ElementAt(i) < objectiveVal)
        {
          return y.ElementAt(i - 1) +
                 (y.ElementAt(i) - y.ElementAt(i - 1)) * ((objectiveVal - x.ElementAt(i)) / (x.ElementAt(i) - x.ElementAt(i - 1)));
        }
      }

      return Double.NaN;
    }

    #endregion
  }

  #region Patient and Field Info Helper Classes

  /// <summary>
  /// Container for generic patient info.
  /// Mind the PHI!
  /// </summary>
  public class PatientInfo
  {
    public string id { get; set; }
    public string name { get; set; }
    public string dob { get; set; }

    public PatientInfo(TP.Patient patient)
    {
      this.id = patient.Id;
      this.name = patient.Name;
      this.dob = patient.DateOfBirth?.ToShortDateString();
    }
  }

  /// <summary>
  /// Container for info regarding all fields in the plan.
  /// </summary>
  public class FieldInfo
  {
    public string planId { get; set; }
    public string courseId { get; set; }
    public string patientId { get; set; }

    /// <summary>
    /// List of field-wise information.
    /// </summary>
    public List<FieldObject> fieldObjects { get; set; }

    public FieldInfo(TP.PlanSetup plan)
    {
      this.planId = plan.Id;
      this.courseId = plan.Course.Id;
      this.patientId = plan.Course.Patient.Id;

      this.fieldObjects = new List<FieldObject>();
      foreach (var field in plan.Beams)
      {
        var gantryAngle = field.ControlPoints.First() != null ? field.ControlPoints.First().GantryAngle : double.NaN;
        var mu = field.Meterset.Value;

        // Record the field delivery time, if available.
        var deliveryTime = double.NaN;

        // When using version older than 18.0, the part below will need to be commented out.
        if (field is TP.IonBeam)
        {
          TPTypes.ProtonDeliveryTimeStatus status = (field as TP.IonBeam).GetDeliveryTimeStatusByRoomId(Script.defaultRoomId);
          if (status != TPTypes.ProtonDeliveryTimeStatus.NotCalculated)
            deliveryTime = (field as TP.IonBeam).GetProtonDeliveryTimeByRoomIdAsNumber(Script.defaultRoomId);
        }

        this.fieldObjects.Add(new FieldObject(field.Id, gantryAngle, mu, deliveryTime));
      }
    }
  }

  /// <summary>
  /// Container for the field info.
  /// </summary>
  public class FieldObject
  {
    /// <summary>
    /// ID of the field.
    /// </summary>
    public string id { get; set; }

    /// <summary>
    /// Angle of the field (deg).
    /// </summary>
    public double angle { get; set; }

    /// <summary>
    /// MU of the field.
    /// </summary>
    public double monitorUnits { get; set; }

    /// <summary>
    /// Delivery time of the field (s).
    /// </summary>
    public double deliveryTime { get; set; }

    public FieldObject(string id, double angle, double monitorUnits, double deliveryTime)
    {
      this.id = id;
      this.angle = angle;
      this.monitorUnits = monitorUnits;
      this.deliveryTime = deliveryTime;
    }
  }

  #endregion

  #region Uncertainty Goal Helper Classes

  /// <summary>
  /// Container for all Clinical Goals and their Uncertainty Scenario results.
  /// </summary>
  public class UncertaintyGoalListContainer
  {
    public string patientId { get; set; }
    public string courseId { get; set; }
    public string planId { get; set; }

    public List<UncertaintyGoalList> uncertaintyGoalLists { get; set; }

    public UncertaintyGoalListContainer(TP.PlanSetup plan)
    {
      this.planId = plan.Id;
      this.courseId = plan.Course.Id;
      this.patientId = plan.Course.Patient.Id;

      this.uncertaintyGoalLists = new List<UncertaintyGoalList>();
    }

    /// <summary>
    /// Generic constructor for the "write to JSON" functionality.
    /// </summary>
    public UncertaintyGoalListContainer()
    {
      this.patientId = "";
      this.courseId = "";
      this.planId = "";
    }
  }

  /// <summary>
  /// Container for all Uncertainty Scenario results for a singe Clinical Goal.
  /// </summary>
  public class UncertaintyGoalList
  {
    /// <summary>
    /// ID of this Clinical Goal's target structure.
    /// </summary>
    public string structureId { get; set; }

    /// <summary>
    /// Clinical Goal's objective as a string.
    /// </summary>
    public string objective { get; set; }

    /// <summary>
    /// Clinical Goal's priority.
    /// </summary>
    public TPTypes.GoalPriority priority { get; set; }

    /// <summary>
    /// List of this Clinical Goal's evaluation results for different Uncertainty Scenarios.
    /// </summary>
    public List<UncertaintyGoal> uncertaintyGoals { get; set; }

    public UncertaintyGoalList(string structureId, string objective, TPTypes.GoalPriority priority)
    {
      this.structureId = structureId;
      this.objective = objective;
      this.priority = priority;

      this.uncertaintyGoals = new List<UncertaintyGoal>();
    }

    /// <summary>
    /// Generic constructor for the "write to JSON" functionality.
    /// </summary>
    public UncertaintyGoalList()
    {
      this.structureId = "";
      this.objective = "";

      this.uncertaintyGoals = new List<UncertaintyGoal>();
    }

    public override string ToString()
    {
      var str = this.structureId + " (" + this.objective + ") | " + this.uncertaintyGoals.Count().ToString();
      return str;
    }
  }

  /// <summary>
  /// Container for a single Clinical Goal - Uncertainty Scenario pair.
  /// Helps with writing results to a file.
  /// </summary>
  public class UncertaintyGoal
  {
    /// <summary>
    /// Name of the Uncertainty Scenario.
    /// </summary>
    public string name { get; set; }

    /// <summary>
    /// Value of the Clinical Goal for this Uncertainty Scenario
    /// </summary>
    public double value { get; set; }

    /// <summary>
    /// Evaluation result for this Clinical Goal - Uncertainty Scenario.
    /// </summary>
    public string goalResult { get; set; }

    public UncertaintyGoal(string name, double value, TPTypes.GoalEvalResult evaluationResult)
    {
      this.name = name;
      this.value = value;
      this.goalResult = evaluationResult.ToString();
    }
  }

  #endregion

  #region NTCP Helper Classes

  /// <summary>
  /// Container for all NTCP Endpoint results.
  /// </summary>
  public class NtcpContainer
  {
    public string patientId { get; set; }
    public string courseId { get; set; }
    public string planId { get; set; }

    public List<NtcpEndpoint> ntcpEndpoints { get; set; }

    public NtcpContainer(TP.PlanSetup plan)
    {
      this.patientId = plan.Course.Patient.Id;
      this.courseId = plan.Course.Id;
      this.planId = plan.Id;

      this.ntcpEndpoints = new List<NtcpEndpoint>();
    }
  }

  /// <summary>
  /// Container for a single NTCP Endpoint.
  /// </summary>
  public class NtcpEndpoint
  {
    /// <summary>
    /// Endpoint ID.
    /// </summary>
    public string id { get; set; }

    /// <summary>
    /// Endpoint name.
    /// </summary>
    public string name { get; set; }

    /// <summary>
    /// Endpoint value.
    /// </summary>
    public double value { get; set; }

    public NtcpEndpoint(string id, string name, double value)
    {
      this.id = id;
      this.name = name;
      this.value = value;
    }
  }

  #endregion
}
